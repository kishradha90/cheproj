import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GrievanceService } from '../services/grievance.service';
import { Grievance } from '../Model/grievance';

@Component({
  selector: 'app-add-grievance',
  templateUrl: './add-grievance.component.html',
  styleUrls: ['./add-grievance.component.css']
})
export class AddGrievanceComponent  {
  
  grievance: Grievance;

  constructor(
    private route: ActivatedRoute, 
      private router: Router, 
        private grievanceService: GrievanceService) {
    this.grievance = new Grievance();
  }

  ngOnInit()
  {
    this.grievance.loginId = sessionStorage.getItem('userId');  
  }

  onSubmit() {
    this.grievanceService.save(this.grievance).subscribe(result => this.gotoGrievanceList());
  }
 
  gotoGrievanceList() {
    this.router.navigate(['/user']);
  }
}
