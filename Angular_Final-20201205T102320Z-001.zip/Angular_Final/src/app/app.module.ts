import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { AddGrievanceComponent } from './add-grievance/add-grievance.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { PersonService } from './services/person.service';
import { HttpClientModule } from '@angular/common/http';
import { GrievanceService } from './services/grievance.service';
import { ListGrievanceComponent } from './list-grievance/list-grievance.component';
import { AddCommentComponent } from './add-comment/add-comment.component';
import { FooterComponent } from './footer/footer.component';
import { UserService } from './services/user.service';
import { AuthGaurdService } from './services/auth-guard.service';
import { LogoutComponent } from './logout/logout.component';
import { CorporatorComponent } from './corporator/corporator.component';
import { AdminComponent } from './admin/admin.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {RoleService} from './services/role.service';
import { VoteService } from './services/vote.service';
import { WardService } from './services/ward.service';
import { CityService } from './services/city.service';
import { QuestionService } from './services/question.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    UserComponent,
    AddGrievanceComponent,
    ListGrievanceComponent,
    AddCommentComponent,
    FooterComponent,
    LogoutComponent,
    CorporatorComponent,
    AdminComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule
  ],
 
  providers: [PersonService,GrievanceService,UserService,AuthGaurdService,RoleService,
              VoteService,WardService,CityService,QuestionService],
  bootstrap: [AppComponent]
})
export class AppModule { }
