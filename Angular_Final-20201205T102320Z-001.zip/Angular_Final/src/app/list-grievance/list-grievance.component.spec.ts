import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListGrievanceComponent } from './list-grievance.component';

describe('ListGrievanceComponent', () => {
  let component: ListGrievanceComponent;
  let fixture: ComponentFixture<ListGrievanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListGrievanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListGrievanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
