import { Component, OnInit } from '@angular/core';
import { Grievance } from '../Model/grievance';
import { GrievanceService } from '../services/grievance.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-grievance',
  templateUrl: './list-grievance.component.html',
  styleUrls: ['./list-grievance.component.css']
})
export class ListGrievanceComponent implements OnInit {

  pageTitle : string;
  grievanceStatus : string;
  grievances: Grievance[];
 
  constructor(private grievanceService: GrievanceService, private router:Router) {
  }
 
  ngOnInit() {
    this.grievanceStatus=sessionStorage.getItem('grievanceStatus');
    
    if(this.grievanceStatus=="Pending")
    {
      this.pageTitle = "Pending Grievances";
        this.pending();
    }

    if(this.grievanceStatus=="Resolved")
    {
      this.pageTitle = "Resolved Grievances";
          this.resolved();
    }
    
    if(sessionStorage.getItem('roleId1')=="resident")
    {

      this.pageTitle = "All Grievances";
      this.grievanceService.findAll().subscribe(data => {
      this.grievances = data;
      });
    }
  }

  onClickComment(grievanceId:number){
    this.router.navigate(['/addComment',grievanceId]);
  }

  pending(){
    this.grievanceService.findByStatus("Pending").subscribe(data=>{this.grievances=data;});
  }

  resolved(){
    this.grievanceService.findByStatus("Resolved").subscribe(data=>{this.grievances=data;});
  }

}
