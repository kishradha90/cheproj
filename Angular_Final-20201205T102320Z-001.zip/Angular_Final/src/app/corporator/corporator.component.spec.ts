import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporatorComponent } from './corporator.component';

describe('CorporatorComponent', () => {
  let component: CorporatorComponent;
  let fixture: ComponentFixture<CorporatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
