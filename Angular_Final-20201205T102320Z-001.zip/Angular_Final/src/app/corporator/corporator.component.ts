import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-corporator',
  templateUrl: './corporator.component.html',
  styleUrls: ['./corporator.component.css']
})
export class CorporatorComponent implements OnInit {

  welcomeCorporatorName:string;

  constructor(private router:Router) { }

  ngOnInit() {

    this.welcomeCorporatorName = sessionStorage.getItem('userId');
  }

  listPending(){
    sessionStorage.setItem('grievanceStatus',"Pending");
    this.router.navigate(['/listGrievance']);
  }

  listResolved(){
    sessionStorage.setItem('grievanceStatus',"Resolved");
    this.router.navigate(['/listGrievance']);
  }

}
