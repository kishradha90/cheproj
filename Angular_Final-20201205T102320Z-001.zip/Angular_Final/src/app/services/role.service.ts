import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})



export class RoleService {

  getRoleUrl:string="http://localhost:8080/role/getRole?roleId=";

  constructor(public http:HttpClient) { }

  getRole(roleId:number)
  {
    return this.http.get(this.getRoleUrl+roleId);
  }

}
