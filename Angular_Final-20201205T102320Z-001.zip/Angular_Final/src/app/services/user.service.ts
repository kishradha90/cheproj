import { Injectable } from '@angular/core';
import { User } from '../Model/user';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  user:User;
  loginId:string;
  //userloginUrl:string="http://localhost:8080/admin/validateAdmin";
  userloginUrl:string="http://localhost:8080/user/validateUser";
  userUsername:string="http://localhost:8080/user/getUserName?loginId=";
  userAddUrl:string="http://localhost:8080/admin/addNewCorporator";
  constructor(public http:HttpClient) { }



  public validateUser(user) {
    return this.http.post(this.userloginUrl,user,{responseType:'text' as 'json'});
  }

  public isUserLoggedIn() {
    let login_logout = sessionStorage.getItem('userId');
    return !(login_logout==null);
  }

  public logOut() {
    sessionStorage.removeItem(this.user.loginId);
    sessionStorage.clear();
  }

  public getUserName(loginId){
    return this.http.get(this.userUsername+loginId);
  }

}
