import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Vote } from '../Model/vote';

@Injectable({
  providedIn: 'root'
})
export class VoteService {

  public API = 'http://localhost:8080/vote';

  constructor(private http: HttpClient) {

   }

   findAll(grievanceId:number): Observable<any> {
    return this.http.get(this.API + '/findVotesByGrievanceId?grievanceId='+grievanceId);
  }
 
  public saveVote(vote: Vote) {
    return this.http.post<Vote>(this.API+'/addVote',vote);
  }

}
