import { TestBed } from '@angular/core/testing';

import { GrievanceService } from './grievance.service';

describe('GrievanceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GrievanceService = TestBed.get(GrievanceService);
    expect(service).toBeTruthy();
  });
});
