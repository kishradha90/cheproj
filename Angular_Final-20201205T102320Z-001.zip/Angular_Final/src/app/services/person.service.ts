
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Person } from '../Model/person';
import { Observable } from 'rxjs';

 
@Injectable()
export class PersonService {
 
  public API = 'http://localhost:8080/admin';
  //public CAR_API = this.API + '/cars';
  userloginUrl:string="http://localhost:8080/admin/validateAdmin";
  constructor(private http: HttpClient) {
  }

  findAll(): Observable<any> {
    return this.http.get(this.API + '/getAllCorporators');
  }
 
  public save(person: Person) {
    return this.http.post<Person>(this.API+'/addNewCorporator', person);
  }
}