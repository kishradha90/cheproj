import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Grievance } from '../Model/grievance';

@Injectable({
  providedIn: 'root'
})
export class GrievanceService {

  public API = 'http://localhost:8080/grievance';
 
  constructor(private http: HttpClient) {
  }

  findAll(): Observable<any> {
    return this.http.get(this.API + '/getAllGrievances');
  }
 
  public save(grievance: Grievance) {
    return this.http.post<Grievance>(this.API+'/addNewGrievance', grievance);
  }

  findByStatus(status:string):Observable<any>{
    return this.http.get(this.API+'/getGrievancesByStatus?status='+status);
  }

  
}
