import { Component, OnInit } from '@angular/core';
import { User } from '../Model/user';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  userName:string;
  user:User;
  message:any;

  constructor(public userService:UserService,public router:Router) {
    this.user = new User("","");
   }

  ngOnInit() {
  }

  public onSubmit() {
    this.userService.validateUser(this.user).subscribe(res=>{

      //alert(resp);

      switch(res)
      {
        case '1': // Admin 
        {
          this.userService.getUserName(this.user.loginId).subscribe(result1=>{
            //alert("result1: "+result1);
            this.userName  = result1.toString();
            sessionStorage.setItem('userName',this.userName);
          });
          sessionStorage.setItem('userId',this.user.loginId);
          this.router.navigate(["/admin"]);
        }
        break;

        case '2': // Corporator
        {
          sessionStorage.setItem('userId',this.user.loginId);
          this.router.navigate(["/corporator"]);
        }
        break;

        case '3': //Resident
        {
          sessionStorage.setItem('roleId1',"resident");
         // alert('Login successfully');
          sessionStorage.setItem('userId',this.user.loginId);
         // alert(sessionStorage.getItem('userId'));
          this.router.navigate(["/user"]);
        }
        break;

        default: alert('Incorrect Username or Password.......!!!');
      
      }

  });
}

}
