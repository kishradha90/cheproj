import { Component, OnInit } from '@angular/core';
import { Person } from '../Model/person';
import { ActivatedRoute, Router } from '@angular/router';
import { PersonService } from '../services/person.service';
import { WardService } from '../services/ward.service';
import { CityService } from '../services/city.service';
import { QuestionService } from '../services/question.service';
import { Ward } from '../Model/ward';
import { Question } from '../Model/question';
import { City } from '../Model/city';
import { Role } from '../Model/role';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent  {

  
  person: Person;
  wardArr : Ward [];
  cityArr :City[];
  questionArr:Question[];
  genderArr:string[]=["male","female"];
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"; 

  constructor(private route: ActivatedRoute, private router: Router, 
              private userService: PersonService,private wardService:WardService,
              private cityService:CityService,private questionService:QuestionService) 
  {
    this.person = new Person();
    this.person.wardIdFk = new Ward();
    this.person.cityIdFk = new City();
    this.person.questionIdFk = new Question();
    this.person.roleIdFk = new Role();
  }

  ngOnInit()
  {
    this.wardService.findAll().subscribe(data => {this.wardArr = data});
    this.cityService.findAll().subscribe(data => {this.cityArr = data});
    this.questionService.findAll().subscribe(data => {this.questionArr = data});
    //alert("hiii");
  }
  
 
  onSubmit() {

   // this.person.wardIdFk.wardId = this.wardId1;
   /* 
    alert("wardId: "+ this.person.wardIdFk.wardId);
    alert("cityId: "+this.person.cityIdFk.cityId);
    alert("qID :"+this.person.questionIdFk.questionId);
    /*alert("gender: "+ this.person.gender);
   /* alert("fullName: "+this.person.fullName);
    alert("Address: "+this.person.addressLine);
    alert("voterId: "+this.person.voterId);
    alert("answer: "+this.person.answer);
    alert("password: "+this.person.password);
    alert("pincode: "+this.person.pinCode);
    alert("gender: "+ this.person.gender);
    alert("cityId :"+this.person.cityIdFk.cityId);
    alert("date: "+this.person.dob);
    alert("contact no: "+this.person.contactNo); */
   
    //alert("onSubmit called");

    this.person.roleIdFk.roleId=3;
    this.userService.save(this.person).subscribe(result => this.gotoLogin());
  }
 
  gotoLogin() {
    this.router.navigate(['/user']);
  }
}
