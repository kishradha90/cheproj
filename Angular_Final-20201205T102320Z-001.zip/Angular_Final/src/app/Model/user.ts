export class User {

    constructor(
        public loginId:string,
        public password:String
       )  { }
}
