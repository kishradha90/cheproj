import { Role } from './role'
import { Ward } from './ward';
import { Question } from './question';
import { City } from './city';

export class Person {
    
    loginId:string
    roleIdFk:Role
    wardIdFk:Ward
    fullName:string
    dob:Date
    gender:string
    voterId:string
    contactNo:string
    imageUrl:string
    addressLine:string
    cityIdFk:City
    pinCode:number
    questionIdFk:Question
    answer:string
    password:string
}