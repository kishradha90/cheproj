
export class Role {  
    roleId:number;
    roleType:string;
}