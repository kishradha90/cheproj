export class Grievance{
    grievanceId:number
    type:string
    loginId:string
    title:string
    description:string
    status:string
    statusDetails:string
    imageUrl:string
    fileDate:string
    resolveDate:string
}