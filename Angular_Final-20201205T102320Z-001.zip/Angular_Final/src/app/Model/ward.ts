
export class Ward {  
    wardId:number;
    wardName:string;

}