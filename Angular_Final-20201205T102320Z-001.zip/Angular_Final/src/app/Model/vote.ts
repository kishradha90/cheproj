export class Vote{
    voteId:number
    loginId:string
    grievanceId:number
    voteStatus:string
    comment:string
}