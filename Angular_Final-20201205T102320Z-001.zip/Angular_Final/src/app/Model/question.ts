export class Question {  
    questionId:number;
    question:string;
}