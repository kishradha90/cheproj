import { Component, OnInit } from '@angular/core';
import {VoteService} from '../services/vote.service'
import {Vote} from '../Model/vote';
import { Router, ActivatedRoute } from '@angular/router';
import { Route } from '@angular/compiler/src/core';

@Component({
  selector: 'app-add-comment',
  templateUrl: './add-comment.component.html',
  styleUrls: ['./add-comment.component.css']
})

export class AddCommentComponent implements OnInit {

  vote : Vote = new Vote;
  commentText:string;
  grievanceId : number;
  votesArr: Vote[];

  constructor(private voteService:VoteService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
    this.grievanceId = this.route.snapshot.params['id'];
    //alert("GID: "+this.grievanceId);
    this.voteService.findAll(this.grievanceId).subscribe(data => {
      this.votesArr = data;
    //  alert("add-comment.ts");
    });
  }

  onSubmit() {
    //alert("onsubmit called");
    //alert(this.commentText);
  
    this.vote.loginId = sessionStorage.getItem('userId');
    this.vote.comment = this.commentText;
    this.vote.grievanceId = this.grievanceId;
    this.voteService.saveVote(this.vote).subscribe(result => 
          this.voteService.findAll(this.grievanceId).subscribe(data => 
            { this.votesArr = data; })
      );
    
  }

}