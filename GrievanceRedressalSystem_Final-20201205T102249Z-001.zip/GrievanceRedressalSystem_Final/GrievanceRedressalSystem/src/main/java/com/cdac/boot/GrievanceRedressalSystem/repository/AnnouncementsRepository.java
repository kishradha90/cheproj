package com.cdac.boot.GrievanceRedressalSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.boot.GrievanceRedressalSystem.entity.AnnouncementEntity;

public interface AnnouncementsRepository extends JpaRepository<AnnouncementEntity, Integer> 
{

}
