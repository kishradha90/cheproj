package com.cdac.boot.GrievanceRedressalSystem.service;

import com.cdac.boot.GrievanceRedressalSystem.entity.RatingEntity;

public interface RatingService
{
	RatingEntity getRating(int ratingId);
}
